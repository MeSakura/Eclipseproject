package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class firefoxclass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//create object for chrome browser  
		System.setProperty("webdriver.gecko.driver", "/home/sakshibhatt/Downloads/seleniumjars/geckodriver");
		WebDriver driver = new FirefoxDriver();
		//driver.get("https://google.com");
		//System.out.println(driver.getTitle());
		
		
	}

}
