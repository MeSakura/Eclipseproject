package project1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class xpath_regex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.rediff.com/");
		//System.out.println(driver.getTitle());
		
		//xpath along with regex 
		driver.findElement(By.cssSelector("a[title*='Already a user?']")).click(); //simple custom regex css xpath
		driver.findElement(By.cssSelector("input[id='login1']")).sendKeys("test"); //simple custom css path
		driver.findElement(By.xpath("//input[@name='passwd']")).sendKeys("hehe"); //simple x-path
		driver.findElement(By.xpath("//input[contains(@name,'procee')]")).click();

	}

}
