package project1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class project1class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//create object for chrome browser  
		System.setProperty("webdriver.chrome.driver", "/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		WebDriver driver = new ChromeDriver();
		driver.get("https://login.salesforce.com/");
		System.out.println(driver.getTitle());
		
		//locators 
		driver.findElement(By.id("username")).sendKeys("rrrrrrrrrrrrrr");
		driver.findElement(By.id("password")).sendKeys("tttttt");
		//driver.findElement(By.linkText("पासवर्ड भूल गए?")).click();
		driver.findElement(By.cssSelector("#Login")).click();
        System.out.println(driver.findElement(By.cssSelector("#error")).getText());
		
		//below xpath is not reiable as it start with html !
		//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[1]/div/div/div/div[2]/div/div[1]/form/div[2]/button")).click();
		
		//driver.get("https://yahoo.com");   //calling yahoo
		//driver.navigate().back();
		//driver.close();
		
		//------css selector and xpath
	//driver.findElement(By.cssSelector("#email")).sendKeys("eeee");
	//driver.findElement(By.cssSelector("#pass")).sendKeys("test");
	//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[1]/div/div/div/div[2]/div/div[1]/form/div[2]/button")).click();
		
	}

}
