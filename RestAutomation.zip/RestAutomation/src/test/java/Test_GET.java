import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;

public class Test_GET {

	@Test
	void method1 ()
	{
		
		Response response= RestAssured.get("https://qanode10.ameyo.com:8443/ameyorestapi/tickets/1628671338248");
		given().header("Authorization","fecace70bf6ea0c450c5b2071cbabc9").header("content-type","application/json");
		
		System.out.println(response.header("sessionId"));
		System.out.println(response.getBody());
		System.out.println(response.asString());
		System.out.println(response.getStatusCode());
		System.out.println(response.getHeader("content-type"));
		System.out.println(response.getStatusLine());
	}
	
}
