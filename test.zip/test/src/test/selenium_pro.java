package test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class selenium_pro{
   public static void main(String[] args) {
      WebDriver driver = new ChromeDriver();
      //browser type and chromedrover.exe path as parameters
      System.setProperty("webdriver.chrome.driver","\\home\\sakshibhatt\\Downloads\\selenium\\chromedriver.exe");
      String url = "https://www.tutorialspoint.com/questions/index.php";
      driver.get(url);
   }
}
