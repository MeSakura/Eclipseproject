package project1;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Kart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		ChromeDriver driver = new ChromeDriver();
		int j=0;
		
		String[] item = {"Brocolli","Cucumber","Beetroot"};
		driver.get("https://rahulshettyacademy.com/seleniumPractise/");
		Thread.sleep(3000);
		
		List<WebElement> product =driver.findElements(By.cssSelector("h4.product-name"));
		
		List itemNeededList = Arrays.asList(item);
		
		for(int i=0; i<product.size();i++)
		{
			String[] name = product.get(i).getText().split("-");
			String format=name[0].trim();
			
			if(itemNeededList.contains(format))
							{
				j++;

				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
				if(j==item.length)
				{
					break;
				}
					}
			
		}
	}

}
