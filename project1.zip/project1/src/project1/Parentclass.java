package project1;

public class Parentclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("iam parent class");

		//yhan parent class mai child class ka  ka method class krnegye
		childclass c = new childclass();
		c.childmethod();
		
	}

}
