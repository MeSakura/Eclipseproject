package project1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ameyoLogin_TC1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		WebDriver driver = new ChromeDriver();
		driver.get("https://qanode10.ameyo.com:8443/app");
		//System.out.println(driver.getTitle());
		
		driver.findElement(By.xpath("//input[@placeholder='User ID']")).sendKeys("testeeeeeer");
		//driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("rrrrrrr");
		// css path 
		driver.findElement(By.cssSelector("input[placeholder='Password']")).sendKeys("eeeeee");
		
		driver.findElement(By.xpath("//button[contains(@class,'btn-primary')]")).click();
		
		System.out.println(driver.findElement(By.xpath("//span[contains(@class,'error-msg')]")).getText());
		
		//driver.close();
	}

}
