package project1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class amazon {
	
	public static void main (String arg[])
	{
		System.setProperty("webdriver.chrome.driver","/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in");
		
		driver.findElement(By.cssSelector("#nav-xshop > a:nth-child(6)")).click();
		
	}

}
