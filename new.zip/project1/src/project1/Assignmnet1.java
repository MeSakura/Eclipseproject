package project1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignmnet1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver","/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		driver.findElement(By.cssSelector("input#checkBoxOption1")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.cssSelector("input#checkBoxOption1")).click();
		
		//by verifying common locator
		
		System.out.println(driver.findElements(By.cssSelector("input[type='checkbox']")).size());
			
	}

}
