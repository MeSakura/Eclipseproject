package project1;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class ProcessCreation_TC {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//browser invocation--------------------
		System.setProperty("webdriver.chrome.driver", "/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
        Map<String, Object> prefs = new HashMap<>();
        prefs.put("profile.default_content_setting_values.notifications", 1);
        prefs.put("profile.default_content_setting_values.media_stream_camera", 1);
        prefs.put("profile.default_content_setting_values.media_stream_mic", 1);
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("prefs", prefs);
		driver = new ChromeDriver(options);
		driver.get("https://qanode10.ameyo.com:8443/app");
		driver.manage().window().maximize();
		//System.out.println(driver.getTitle());
		
		//locator invocation & successful invocation---------------------------
		driver.findElement(By.xpath("//input[@placeholder='User ID']")).sendKeys("admin");
		//driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("Administrator");
		// css path 
		driver.findElement(By.cssSelector("input[placeholder='Password']")).sendKeys("admin");
		driver.findElement(By.xpath("//button[contains(@class,'btn-primary')]")).click();
		//System.out.println(driver.findElement(By.xpath("//span[contains(@class,'error-msg')]")).getText());
		
		//process invocation...............
		//driver.findElement(By.xpath("//a[@id='automationIdProcessLink']")).click();
		//driver.findElement(By.cssSelector("a[id='automationIdProcessLink']")).click();
		try {
			driver.switchTo().alert().accept();
		} catch (Exception e) {
			System.out.println("No Alert Found in UI");
		}
		
		Wait<WebDriver> wait = new FluentWait(driver).withTimeout(20, TimeUnit.SECONDS)
                .pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);
		WebElement processTab = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='automationIdProcessLink']/span")));
		if(processTab!=null) {
			driver.findElement(By.xpath("//a[@id='automationIdProcessLink']/span")).click();
		}
		else {
			System.out.println("Process tab not visible");
		}
		//voice regression process click .....
		driver.findElement(By.xpath("//span[contains(text(),'monika_process')]")).click();
		driver.findElement(By.cssSelector("input#gwt-uid-578")).sendKeys("https://qanode10.ameyo.com:8786/crmprops");
		driver.findElement(By.cssSelector("textarea#gwt-uid-579")).sendKeys("Testing process");
		driver.findElement(By.xpath("//span[contains(text(),'Apply')]")).click();
		
		//driver.close();
	}
}
