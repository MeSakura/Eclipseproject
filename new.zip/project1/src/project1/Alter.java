package project1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String text= "Rahul";
		
		System.setProperty("webdriver.chrome.driver","/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		
		//Ok alert 
		driver.findElement(By.id("name")).sendKeys(text);
		driver.findElement(By.id("alertbtn")).click();
		
		driver.switchTo().alert().accept();
		
		//confirmation alert
		driver.findElement(By.id("name")).sendKeys(text);
		driver.findElement(By.id("confirmbtn")).click();
		driver.switchTo().alert().dismiss();
		
	}

}
