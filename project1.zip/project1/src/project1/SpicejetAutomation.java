package project1;

import org.openqa.selenium.chrome.ChromeDriver;

public class SpicejetAutomation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//invoking spicejet website
		System.setProperty("webdriver.chrome.driver","/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://spicejet.com");

		//selecting destination
		
	 
	}

}
