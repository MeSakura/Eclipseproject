package project1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class Checkbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","/home/sakshibhatt/Downloads/seleniumjars/chromedriver");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		
		driver.findElement(By.cssSelector("input#ctl00_mainContent_chk_SeniorCitizenDiscount")).click();
		//driver.findElement(By.cssSelector("input#ctl00_mainContent_chk_SeniorCitizenDiscount")).isSelected();
		
		//uper wala path assertions se call krwane ka treeka  neeche wale case mai assert fail ho jyega qki condition true h aur assert false h 
		Assert.assertFalse(driver.findElement(By.cssSelector("input#ctl00_mainContent_chk_SeniorCitizenDiscount")).isSelected());
		
		
	}

}
