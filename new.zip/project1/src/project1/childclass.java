package project1;

public class childclass {

	public void childmethod()
	{
	System.out.println("iam child class");
	}
}
